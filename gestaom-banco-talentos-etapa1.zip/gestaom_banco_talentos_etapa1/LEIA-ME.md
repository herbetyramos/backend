# GestãoM — Banco de Talentos — Etapa 1 (base inicial)

Este pacote contém os arquivos criados/alterados para a primeira etapa. Ele foi preparado a partir dos ZIPs do projeto enviados em 08/11/2026. **Não copie a pasta inteira por cima do projeto sem conferir os arquivos indicados.**

## Decisões implementadas

- Elegibilidade do aluno: pelo menos uma matrícula com `aprovado = true`. `confirmacao_formatura` não é consultado.
- O cadastro `empresa` existente permanece inalterado em sua finalidade: fornecedoras relacionadas às atas/detentoras.
- Novas empresas empregadoras usam `EmpresaParceira` / tabela `empresa_parceira`.
- Aluno usa autenticação independente: CPF + senha, primeiro acesso com código individual de uso único.
- Cookie do aluno: `@nextauth.aluno.token`; cookie administrativo existente: `@nextauth.token`.
- Token do aluno tem claim `tipo: "aluno"`; middleware administrativo rejeita esse tipo e middleware de aluno exige esse tipo.
- Código de ativação: oito caracteres hexadecimais, armazenado com hash, validade de 48 horas e bloqueio temporário após tentativas inválidas.

## Arquivos

Os caminhos dentro de `backend/` e `frontend/` são relativos às raízes correspondentes dos projetos.

### Backend

- `prisma/schema.prisma` — modelos e relações novos.
- `prisma/migrations/20261108120000_banco_talentos_etapa1/migration.sql` — criação das tabelas.
- `src/modules/bancoTalentos/routes.ts` — endpoints administrativos e do aluno.
- `src/routes/routes.ts` — montagem das rotas.
- `src/middleware/IsAuthenticated.ts` — bloqueia token de aluno nas rotas administrativas.
- `src/@types/express/index.d.ts` — tipagem do identificador do aluno autenticado.

### Frontend

- `src/app/banco-talentos/acesso/page.tsx` — login e ativação do aluno.
- `src/app/banco-talentos/perfil/page.tsx` — perfil profissional e formações aprovadas.
- `src/app/banco-talentos/admin/page.tsx` — lista de alunos elegíveis, emissão de código e cadastro/aprovação de empresas.
- `src/services/bancoTalentosApi.ts` — cliente HTTP com token independente do aluno.
- `src/components/Sidebar/index.tsx` — links do módulo.
- `src/middleware.ts` — proteção de páginas administrativas e do perfil do aluno.

## Rotas adicionadas

### Secretaria (exigem token administrativo)

- `GET /banco-talentos/admin/alunos-elegiveis`
- `POST /banco-talentos/admin/alunos/:alunoId/codigo-ativacao`
- `POST /banco-talentos/admin/empresas`
- `GET /banco-talentos/admin/empresas`
- `PATCH /banco-talentos/admin/empresas/:id/status`

### Aluno

- `POST /banco-talentos/aluno/ativar`
- `POST /banco-talentos/aluno/login`
- `GET /banco-talentos/aluno/me` (token exclusivo do aluno)
- `PUT /banco-talentos/aluno/perfil` (token exclusivo do aluno)

## Aplicação local — antes de produção

1. Faça backup do banco local e mantenha cópia dos arquivos atuais.
2. Copie os arquivos do pacote para as raízes correspondentes, preservando os demais arquivos.
3. Na pasta do backend, execute:

   ```bash
   npx prisma format --schema prisma/schema.prisma
   npx prisma validate --schema prisma/schema.prisma
   npx prisma migrate dev
   npx prisma generate
   npx tsc
   ```

4. Na pasta do frontend, execute:

   ```bash
   yarn build
   ```

5. Faça o teste manual descrito abaixo. Não aplique migration na VPS antes de validar localmente e revisar o SQL.

## Teste manual sugerido

1. Entre no GestãoM com usuário administrativo.
2. Abra `/banco-talentos/admin`.
3. Confirme que a lista mostra somente alunos com alguma matrícula `aprovado = true`, independentemente de `confirmacao_formatura`.
4. Gere o código de um aluno não ativado. A tela o exibe uma única vez; entregue-o ao aluno.
5. Abra `/banco-talentos/acesso`, selecione Primeiro acesso e ative com CPF, código e senha de pelo menos 8 caracteres.
6. Confirme que o aluno chega a `/banco-talentos/perfil`, vê as formações aprovadas e consegue salvar o perfil.
7. Saia e teste o login por CPF e senha.
8. Teste que o token do aluno não consegue acessar `/me` nem endpoints administrativos.
9. Cadastre uma empresa empregadora, confirme que começa como `PENDENTE`, aprove e teste reprovação/suspensão.
10. Confirme que a tabela `empresa` e o cadastro de fornecedoras/atas continuam funcionando.

## Limitações desta etapa

Esta etapa estabelece cadastro, aprovação, elegibilidade, ativação e perfil inicial. Ainda não inclui login do usuário da empresa, publicação de vagas, pesquisa de talentos, candidaturas, convites ou entrevistas; essas partes pertencem às etapas seguintes.

O pacote foi revisado estaticamente. O ambiente de análise não possui as dependências `node_modules` do projeto, então não foi possível executar a validação real do Prisma nem os builds completos. Os comandos acima devem ser executados no ambiente local do projeto antes de qualquer deploy.
